# ─────────────────────────────────────────────────────────────────────────
# (A) PyTorch 안전 로더에 numpy 관련 객체들을 허용하기 위한 코드
# ─────────────────────────────────────────────────────────────────────────
import torch
from torch.serialization import add_safe_globals

# numpy 내부 타입들을 임포트
import numpy as np
from numpy.core import multiarray
from numpy import dtype, ndarray

# Bark 체크포인트 안에 있는 여러 numpy 타입(예: multiarray.scalar, dtype, ndarray 등)을 허용 목록에 추가
add_safe_globals([
    multiarray.scalar,      # numpy.core.multiarray.scalar
    dtype,                  # numpy.dtype
    ndarray,                # numpy.ndarray

    np.float32,             # numpy.float32
    np.float64,             # numpy.float64
    np.int32,               # numpy.int32
    np.int64,               # numpy.int64
    np.generic,             # numpy.generic (보다 일반적인 스칼라용)
    np.dtypes.Float64DType
])

# ─────────────────────────────────────────────────────────────────────────
# (B) 이제 Bark TTS 임포트
# ─────────────────────────────────────────────────────────────────────────
from bark import SAMPLE_RATE, generate_audio, preload_models

# ─────────────────────────────────────────────────────────────────────────
# (C) 나머지 필요한 라이브러리 임포트
# ─────────────────────────────────────────────────────────────────────────
import os
import tempfile
import soundfile as sf

from flask import Flask, request, send_file, jsonify, render_template
from dotenv import load_dotenv
from openai import OpenAI
from transformers import AutoProcessor, MusicgenForConditionalGeneration
import music21
from gtts import gTTS

# ─────────────────────────────────────────────────────────────────────────
# (D) 환경 변수 로드 및 Flask 앱 초기화
# ─────────────────────────────────────────────────────────────────────────
load_dotenv()
app = Flask(__name__)

# OpenAI GPT 초기화 (가사 생성용)
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
openai_client = OpenAI(api_key=OPENAI_API_KEY)


# ────────────────────────────────────────────────────────
# (2) MusicGen-small 로드 (멜로디 생성)
# ────────────────────────────────────────────────────────
MODEL_ID_MELODY = "facebook/musicgen-small"
print("🔧 [Melody] MusicGen-small 모델 로드 중…")
processor_melody = AutoProcessor.from_pretrained(MODEL_ID_MELODY)
model_melody = MusicgenForConditionalGeneration.from_pretrained(MODEL_ID_MELODY)
print("✅ [Melody] MusicGen-small 로드 완료")


# ────────────────────────────────────────────────────────
# (3) Bark TTS 모델 preload (노래 합성용)
# ────────────────────────────────────────────────────────
# Bark TTS는 GitHub로부터 설치했기 때문에,
# 아래를 호출하면 필요한 내부 모델(weights 등)을 자동으로 내려받고 로드합니다.
print("🔧 [Singing] Bark TTS 모델 preload…")
preload_models()
print("✅ [Singing] Bark TTS 로드 완료")


# ────────────────────────────────────────────────────────
# (4) Music21 + MuseScore 설정 (악보 생성용)
# ────────────────────────────────────────────────────────
# 반드시 본인 PC에 설치된 MuseScore 4의 경로로 고쳐주세요.
music21.environment.set(
    "musicxmlPath", r"C:\Program Files\MuseScore 4\bin\MuseScore4.exe"
)
music21.environment.set(
    "musescoreDirectPNGPath", r"C:\Program Files\MuseScore 4\bin\MuseScore4.exe"
)


# ────────────────────────────────────────────────────────
# (5) Flask 라우트 정의
# ────────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html")


# ────────────────────────────────────────────────────────
# ① /generate-lyrics : OpenAI GPT로 간단한 한국어 가사 생성
# ────────────────────────────────────────────────────────
@app.route("/generate-lyrics", methods=["POST"])
def generate_lyrics():
    try:
        payload = request.get_json() or {}
        topic = payload.get("topic", "봄날의 바람")
        prompt = f"'{topic}'이라는 주제로 한국어 노래 가사를 써줘. 4줄 이상."
        response = openai_client.chat.completions.create(
            model="gpt-4",
            messages=[{"role": "user", "content": prompt}]
        )
        lyrics = response.choices[0].message.content.strip()
        return jsonify({"lyrics": lyrics})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ────────────────────────────────────────────────────────
# ② /generate-melody : MusicGen-small로 “가사 기반 멜로디” 생성 → WAV 반환
#    (max_new_tokens 파라미터를 키워서 길이를 늘림)
# ────────────────────────────────────────────────────────
@app.route("/generate-melody", methods=["POST"])
def generate_melody():
    try:
        payload = request.get_json() or {}
        lyrics = payload.get("lyrics", "봄날의 바람이 부는 풍경에 어울리는 밝은 노래")

        # 1) 프롬프트 처리
        inputs = processor_melody(
            text=lyrics,
            padding=True,
            return_tensors="pt"
        )

        # 2) 실제 멜로디 생성
        #    max_new_tokens 값을 크게 잡으면 (예: 1024 → 2048 → 4096) 더 긴 오디오가 나옴.
        #    아래 예시는 2048 토큰으로, 약 20~30초 분량 정도 됩니다.
        audio_values = model_melody.generate(
            **inputs,
            max_new_tokens=2048,  # ← 여기 숫자를 더 크거나 작게 조정하세요
            do_sample=True        # ← 다양성을 높이려면 True
        )

        # 3) WAV 파일로 저장 (임시 경로)
        with tempfile.NamedTemporaryFile(delete=False, suffix=".wav") as f:
            # audio_values[0] shape: (채널수=1, 샘플 길이)일 때, .T로 바꿔 저장
            sf.write(f.name, audio_values[0].cpu().numpy().T, 32000)
            tmp_path = f.name

        # 4) 브라우저로 전송
        return send_file(
            tmp_path,
            mimetype="audio/wav",
            as_attachment=True,
            download_name="melody.wav"
        )
    except Exception as e:
        print("멜로디 생성 에러:", e)
        return jsonify({"error": str(e)}), 500


# ────────────────────────────────────────────────────────
# ③ /generate-singing : Bark TTS로 “가사 기반 노래 합성” → WAV 반환
#    (길이를 늘리려면 Bark 파라미터를 추가 조정할 수 있음)
# ────────────────────────────────────────────────────────
@app.route("/generate-singing", methods=["POST"])
def generate_singing():
    try:
        payload = request.get_json() or {}
        lyrics = payload.get("lyrics", "봄날의 바람이 부는 풍경에 어울리는 밝은 노래")

        # Bark TTS: text=lyrics 만 넣어도 내부적으로 “노래 음성 + 멜로디”를 생성합니다.
        # 필요에 따라 history_prompt, tokens_to_generate 등 파라미터 조정 가능
        wav_array = generate_audio(
            text=lyrics,
            history_prompt="v2/en_singing_bass",  # 가이드톤(베이스/피치), Bark 기본 예시
            sample_rate=SAMPLE_RATE,
            # tokens_to_generate=650000  # → 샘플 길이를 늘리고 싶다면 이 파라미터 활용
        )

        # Bark 결과(넘파이 배열)를 WAV로 저장
        with tempfile.NamedTemporaryFile(delete=False, suffix=".wav") as f:
            sf.write(f.name, wav_array, SAMPLE_RATE)
            tmp_path = f.name

        return send_file(
            tmp_path,
            mimetype="audio/wav",
            as_attachment=True,
            download_name="singing.wav"
        )
    except Exception as e:
        print("노래 합성 에러:", e)
        return jsonify({"error": str(e)}), 500


# ────────────────────────────────────────────────────────
# ④ /generate-score : 간단한 “코드 진행 → 악보 PNG(Base64)” 예시
#    → 실제 모델 멜로디를 MIDI→악보로 바꾸려면 “음성→MIDI 변환” 알고리즘이 필요
# ────────────────────────────────────────────────────────
@app.route("/generate-score", methods=["POST"])
def generate_score():
    try:
        payload = request.get_json() or {}
        # 여기서는 모델 멜로디 대신 예시 코드 진행(C–G–Am–F)을 그립니다.
        score = music21.stream.Score()
        part = music21.stream.Part()
        part.append(music21.metadata.Metadata(title="자동 생성 악보"))
        part.metadata.title = "자동 생성 악보"
        part.append(music21.meter.TimeSignature("4/4"))
        part.append(music21.key.Key("C"))

        chords = ["C", "G", "Am", "F"]
        for _ in range(2):
            for cs in chords:
                c = music21.chord.Chord(cs)
                c.quarterLength = 4
                part.append(c)

        score.append(part)

        # PNG로 저장 → Base64 인코딩
        with tempfile.NamedTemporaryFile(delete=False, suffix=".png") as f:
            score.write("musicxml.png", fp=f.name)
            f.seek(0)
            img_data = f.read()
            b64_png = base64.b64encode(img_data).decode("utf-8")

        return jsonify({"score_png": b64_png})
    except Exception as e:
        print("악보 생성 에러:", e)
        return jsonify({"error": str(e)}), 500


# ────────────────────────────────────────────────────────
# ⑤ /tts : gTTS로 가사 낭독 (선택)
# ────────────────────────────────────────────────────────
@app.route("/tts", methods=["POST"])
def tts():
    try:
        payload = request.get_json() or {}
        text = payload.get("text", "안녕하세요, AI 음악 생성기입니다.")
        tts = gTTS(text, lang="ko")
        with tempfile.NamedTemporaryFile(delete=False, suffix=".mp3") as f:
            tts.save(f.name)
            tmp_path = f.name

        return send_file(
            tmp_path,
            mimetype="audio/mpeg",
            as_attachment=True,
            download_name="tts.mp3"
        )
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ────────────────────────────────────────────────────────
# 메인 실행부
# ────────────────────────────────────────────────────────
if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
